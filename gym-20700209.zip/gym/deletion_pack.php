<?php
include 'config.php';

if(isset($_GET['packet'])){
$packet=$_GET['packet'];

include 'dbcon.php';


$qry3="DELETE from packs where packet='".$packet."'";
$result=mysqli_query($conn,$qry3);
if($result){
    echo"DELETED";
    header('Location:listspackage.php');
}else{
    echo"ERROR!!";
}
}
mysqli_close($conn);
?>