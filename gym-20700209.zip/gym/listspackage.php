
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Packages</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
    .nav-item{
  color:black;
  font-size:15px;
  font-weight: bold;
}

h2 {
    margin: 0 0 15px;
    text-align: center;
    color: orangered;
}
body {
  background-image: url('images/bck8.jpg');
  background-repeat: no-repeat;
  height: 100%;
  background-size: cover;

}
tbody{
  color: white;
  text-align: center;
font-size: 15px;
}
th{
  color: white;
  text-align: center;
  font-size: 20px;
  font-weight: bold;
}
</style>
  </head>
<body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<nav class="navbar navbar-expand-lg navbar-light bg-light" >
  <a class="navbar-brand" href="index.php"><img src="images/logob.png" alt="logow" width="100" height="75"></a><pre>            </pre>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link " href="login.php">Sign-in <span class="sr-only">(current)</span></a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link" href="members.php">Members</a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link" href="addpackage.php">Add Package</a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link " href="listspackage.php">List Packages</a>
    </div>
  </div>
</nav>
<!-- table start here-->
 <h2><b>List Packages</b></h2>
<?php

include "dbcon.php";
$qry="select * from packs";
$cnt = 1;
  $result=mysqli_query($conn,$qry);

  
    echo"<table class='table table-bordered table-hover'>
        <thead>
          <tr>
          <th>#</th>
          <th>Packet-name</th>
          <th>Amount</th>
          <th>Start-Date</th>
          <th>End-Date</th>
          <th>Action</th>
          </tr>
        </thead>";
        
      while($row=mysqli_fetch_array($result)){
      
        echo"<tbody> 
        <td>".$cnt."</td>
        <td>".$row['packet']."</td>
        <td>$".$row['price']."</td>
        <td>".$row['start_D']."</td>
        <td>".$row['end_d']."</td> 
          <td><div class='text-center'><a href='deletion_pack.php?packet=".$row['packet']."' style='color:#F66;'><i class='icon icon-trash'></i> Remove</a></div></td>
          
        </tbody>";
     $cnt++; }
      ?>

      </table>
</body>
</html>