<?php
include "config.php";
if(isset($_REQUEST["register"])){
  $fname = $_REQUEST["fname"];
  $lname = $_REQUEST["lname"];
  $uname = $_REQUEST["uname"];
  $pass = $_REQUEST["pass"];
  $dob = $_REQUEST["dob"];
  $period = $_REQUEST["period"];
  $gender = $_REQUEST["gender"];
  $ins1 = "INSERT into register(fname, lname, uname, pass, dob, period,gender) VALUES  ('$fname','$lname','$uname','$pass','$dob','$period','$gender') ";
  $squery = mysqli_query($conn, $ins1);
	
  
}?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<style>    
body {
  background-image: url('images/bck2.jpg');
  background-repeat: no-repeat;
  height: 100%;
  background-size: cover;
}
.nav-item{
  color:black;
  font-size:15px;
  font-weight: bold;
}
.btn{
	color: white;
	background: #ff6600;
}
.form-control {
	height: 40px;
	box-shadow: none;
	color: black;
}
.form-control:focus {
	border-color: black;
}
.form-control, .btn {        
	border-radius: 3px;
}
.signup-form {
	width: 450px;
	margin: 0 auto;
	padding: 30px 0;
  	font-size: 15px;
}
.signup-form h2 {
	color: #ff6600;
	margin: 0 0 15px;
	position: relative;
	text-align: center;
}
.signup-form h2:before, .signup-form h2:after {
	content: "";
	height: 2px;
	width: 30%;
	background: #d4d4d4;
	position: absolute;
	top: 50%;
	z-index: 2;
}	
.signup-form h2:before {
	left: 0;
}
.signup-form h2:after {
	right: 0;
}
.signup-form .hint-text {
	color: #ff6600;
	margin-bottom: 30px;
	text-align: center;
	font-weight: bold;
}
.signup-form form {
	color: rgb(205, 97, 35);
	border-radius: 3px;
	margin-bottom: 15px;
	background: white;
	box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	padding: 30px;
}
.signup-form .form-group {
	margin-bottom: 20px;
	color: black;
}
.signup-form input[type="checkbox"] {
	margin-top: 3px;
}
.signup-form .btn {        
	font-size: 16px;
	font-weight: bold;		
	min-width: 140px;
	outline: none !important;
}
.signup-form .row div:first-child {
	padding-right: 10px;
}
.signup-form .row div:last-child {
	padding-left: 10px;
}    	

.text-center-cr{
	color:white;
	font-size: 15px;
	text-align: center;
	
}
.text-center-cr:hover{
	font-size: 20px;
	color:white;
}

.form-group{
	color: black;
	text-decoration: none;
}
.btn-block:hover{
	background-color: black;
	border-color: black;
}	

</style>
</head>
<body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<nav class="navbar navbar-expand-lg navbar-light bg-light" >
  <a class="navbar-brand" href="index.php"><img src="images/logob.png" alt="logow" width="100" height="75"></a><pre>            </pre>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link " href="login.php">Sign-in <span class="sr-only">(current)</span></a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link" href="members.php">Members</a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link" href="addpackage.php">Add Package</a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link " href="listspackage.php">List Packages</a>
    </div>
  </div>
</nav>
<div class="signup-form">
    <form >
		<h2>Register</h2>
		<p class="hint-text">COME JOIN US NOW!</p>
        <div class="form-group">
			<div class="row">
				<div class="col"><input type="text" class="form-control" name="fname" placeholder="First Name" required="required"></div>
				<div class="col"><input type="text" class="form-control" name="lname" placeholder="Last Name" required="required"></div>
			</div>        	
        </div>
        <div class="form-group">
        	<input type="text" class="form-control" name="uname" placeholder="Username" required="required">
        </div>
		<div class="form-group">
            <input type="password" class="form-control" name="pass" placeholder="Password" required="required">
        </div>
        <div class="form-group">
            <input  type="date" class="form-control" name="dob" placeholder="Date of Birth" required="required">
        </div> 
		<div class="form-group">
            <select   class="form-control" name="period" placeholder="Period" required="required">
				<option value="3 months">3 months</option>
				<option value="6 months">6 months</option>
				<option value="9 months">9 months</option>
				<option value="12 months">12 months</option>
			</select>
        </div> 
		<div class="form-group">
		<select class="form-control" name="gender" placeholder="Gender" required="required">
				<option value="Male">Male</option>
				<option value="Female">Female</option>
			</select>
        </div> 
        <div class="form-group">
			<label class="form-check-label"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
		</div>
		<div class="form-group">
            <input type="submit" name="register" class="btn btn-success btn-lg btn-block">
        </div>
    </form>
<center><a class="text-center-cr" href="login.php">Sign in</a></center>
</div>
</body>
</html>