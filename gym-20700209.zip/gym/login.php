<?php
session_start();
require('config.php');
$username="";
$errors = array(); 

if (isset($_POST['login'])) {
  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);
  if (count($errors) == 0) {
    $query = "SELECT * FROM login WHERE username='$username' AND password='$password'";
    $results = mysqli_query($conn, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['username'] = $username;
      header("location:members.php");
    }else {
      array_push($errors, "<div class='alert alert-warning'><b>Wrong username/password combination</b></div>");
    }
  }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign-in</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
.login-form {
    width: 500px;
    margin: 70px auto;
  	font-size: 15px;
}
.login-form form {
    margin-bottom: 15px;
    background: white;
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    padding: 30px;
}
.login-form h2 {
    margin: 0 0 15px;
    
}
.form-control, .btn {
    min-height: 38px;
    border-radius: 2px;
 
}
.btn {        
    font-size: 15px;
    font-weight: bold;
    background-color: #ff6600;
    border-color: white;   
}
.btn:hover {
  background-color: black;
  border-color: white;  
}
.btn:active{
  background-color: black;  
}
.nav-item{
  color: black;
}
body 
  {
  background-image: url('images/sig2.jpg');
  background-repeat: no-repeat;
  height: 100%;
  background-size: cover;
}

.text-center-all{
  color: #ff6600;
  text-align: center;
}
.nav-item{
  color:black;
  font-size:15px;
  font-weight: bold;
}
.text-center-cr{
  color:white;
  text-align: center;
}
.text-center-cr:hover{
  color:white;
  font-size: 20px;
}
.float-right{
  color:black;
}
.float-right:hover {
  color: black;
}
</style>
  </head>
<body >
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<nav class="navbar navbar-expand-lg navbar-light bg-light" >
  <a class="navbar-brand" href="index.php"><img src="images/logob.png" alt="logow" width="100" height="75"></a><pre>            </pre>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link " href="login.php">Sign-in <span class="sr-only">(current)</span></a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link" href="members.php">Members</a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link" href="addpackage.php">Add Package</a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link " href="listspackage.php">List Packages</a>
    </div>
  </div>
</nav>
<div class="login-form">
    <form action="" method="post">
      <img src="" alt="">
        <h2 class="text-center-all">Sign-in</h2>       
        <div class="form-group">
            <input type="text" class="form-control" placeholder="Username" name="username" required="required">
        </div>
        <div class="form-group">
            <input type="password" class="form-control" placeholder="Password" name="password" required="required">
        </div>
        <div class="form-group">
            <button type="submit" name="login" class="btn btn-primary btn-block">Log in</button>
        </div>
        <div class="clearfix">
            <label class="float-left form-check-label"><input type="checkbox"> Remember me</label>
            <a href="#" class="float-right">Forgot Password?</a>
        </div>        
    </form>
    <center>
    <p ><a class="text-center-cr" href="register.php">Register</a></p>
    </center>
    
</div>

</body>
</html>