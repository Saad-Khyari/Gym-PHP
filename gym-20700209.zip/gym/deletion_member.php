<?php
include 'config.php';

if(isset($_GET['uname'])){
$uname=$_GET['uname'];

include 'dbcon.php';


$qry4="DELETE from register where uname='".$uname."'";
$result=mysqli_query($conn,$qry4);
if($result){
    echo"DELETED";
    header('Location:members.php');
}else{
    echo"ERROR!!";
}
}
mysqli_close($conn);
?>