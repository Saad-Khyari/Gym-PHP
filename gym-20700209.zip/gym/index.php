<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page 	</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
    .nav-item{
  color:black;
  font-size:15px;
  font-weight: bold;
}
body {
  background-image: url('images/bck5.jpg');
  background-repeat: no-repeat;
  height: 100%;
  background-size: cover;

}
h1{
	color: orangered;
	text-align: left;
	text-shadow: chocolate 3px;
	font-size: 60px;
	font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif ;
	font-weight: bold;
}
h3{color: black;
	text-align: left;
	text-shadow: chocolate 3px;
	font-size: 20px;
	font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;}
	b{
		color: orangered;
		font-size: 25px;
	} 
	.btn{
	font-size: 16px;
	font-weight: bold;		
	min-width: 140px;
	outline: none !important;
	background-color: orangered;
	color:black;
	}
	pre{
		font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
		color:black;
	}
	.btn:hover{
		background-color: black;
		color: white;
	}
</style>
</head>
<body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<nav class="navbar navbar-expand-lg navbar-light bg-light" >
  <a class="navbar-brand" href="index.php"><img src="images/logob.png" alt="logow" width="100" height="75"></a><pre>            </pre>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link " href="login.php">Sign-in <span class="sr-only">(current)</span></a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link" href="members.php">Members</a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link" href="addpackage.php">Add Package</a>&nbsp;&nbsp;&nbsp;
      <a class="nav-item nav-link " href="listspackage.php">List Packages</a>
    </div>
  </div>
</nav>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<div class="page-home">
      <h1 class="page-home-text white">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;HERE WHERE  <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CHANGE BEGINS</h1>
	  <br><br>
      <h3 class="page-home-jumbo page-home-text-white page-home-hide-small"><pre>                     with<b> EMU GYM</b> nothing is <b> IMPOSSIBLE</b></pre></h3><br>
	 <pre>                                          <input type="button" class="btn" onclick="location.href='register.php';" value="JOIN US NOW!" /></pre> 
    </div>

</body>
</html>